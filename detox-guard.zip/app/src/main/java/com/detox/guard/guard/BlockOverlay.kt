package com.detox.guard.guard

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView

/** Full-screen "blocked" notice drawn with an accessibility overlay (needs no extra permission). */
object BlockOverlay {
    private val handler = Handler(Looper.getMainLooper())
    private var view: View? = null

    fun show(service: AccessibilityService, message: String, durationMs: Long = 2000L) {
        handler.post {
            val wm = service.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            removeNow(wm)
            val tv = TextView(service).apply {
                text = "\uD83D\uDD12 Detox Guard\n\n$message"
                setTextColor(Color.WHITE)
                textSize = 20f
                gravity = Gravity.CENTER
                setPadding(64, 64, 64, 64)
            }
            val root = FrameLayout(service).apply {
                setBackgroundColor(0xF2101418.toInt())
                addView(tv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            try {
                wm.addView(root, lp)
                view = root
                handler.postDelayed({ removeNow(wm) }, durationMs)
            } catch (e: Exception) {
                Log.w("BlockOverlay", "overlay failed", e)
            }
        }
    }

    private fun removeNow(wm: WindowManager) {
        handler.removeCallbacksAndMessages(null)
        view?.let {
            try { wm.removeView(it) } catch (e: Exception) { /* already gone */ }
        }
        view = null
    }
}
