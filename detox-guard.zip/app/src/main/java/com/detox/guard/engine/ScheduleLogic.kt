package com.detox.guard.engine

import com.detox.guard.data.PrefsState
import com.detox.guard.data.Schedule
import java.util.Calendar

data class Snapshot(
    val apps: Boolean,
    val settings: Boolean,
    val adult: Boolean,
    val focusActive: Boolean,
    val activeNames: List<String>
) {
    val any: Boolean get() = apps || settings || adult
}

/** Pure time logic: no Android services, easy to reason about. */
object ScheduleLogic {

    /** Monday = 0 ... Sunday = 6 */
    fun dayIndex(cal: Calendar): Int = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7

    private fun daySelected(s: Schedule, idx: Int): Boolean = ((s.daysMask shr idx) and 1) == 1

    fun isActive(s: Schedule, cal: Calendar): Boolean {
        if (!s.enabled || s.daysMask == 0) return false
        val idx = dayIndex(cal)
        val minute = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        return when {
            s.startMinute == s.endMinute -> daySelected(s, idx)
            s.startMinute < s.endMinute ->
                daySelected(s, idx) && minute >= s.startMinute && minute < s.endMinute
            else -> // crosses midnight; the day mask refers to the day the window starts
                (daySelected(s, idx) && minute >= s.startMinute) ||
                    (daySelected(s, (idx + 6) % 7) && minute < s.endMinute)
        }
    }

    fun compute(schedules: List<Schedule>, prefs: PrefsState, now: Long): Snapshot {
        val cal = Calendar.getInstance().apply { timeInMillis = now }
        val active = schedules.filter { isActive(it, cal) }
        val focus = prefs.focusUntil > now
        return Snapshot(
            apps = focus || active.any { it.blockApps },
            settings = focus || active.any { it.blockSettings },
            adult = focus || prefs.alwaysAdult || active.any { it.blockAdult },
            focusActive = focus,
            activeNames = active.map { it.name }
        )
    }

    /** Next moment (strictly after [now]) at which any schedule starts or ends. */
    fun nextBoundaryMillis(schedules: List<Schedule>, now: Long): Long? {
        var best: Long? = null
        for (s in schedules) {
            if (!s.enabled || s.daysMask == 0) continue
            for (d in -1..7) {
                val day = Calendar.getInstance().apply {
                    timeInMillis = now
                    add(Calendar.DAY_OF_YEAR, d)
                    set(Calendar.HOUR_OF_DAY, 0)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                if (!daySelected(s, dayIndex(day))) continue
                val start = (day.clone() as Calendar).apply { add(Calendar.MINUTE, s.startMinute) }.timeInMillis
                val end = (day.clone() as Calendar).apply {
                    add(Calendar.MINUTE, s.endMinute)
                    if (s.endMinute <= s.startMinute) add(Calendar.DAY_OF_YEAR, 1)
                }.timeInMillis
                for (t in longArrayOf(start, end)) {
                    val b = best
                    if (t > now && (b == null || t < b)) best = t
                }
            }
        }
        return best
    }
}
