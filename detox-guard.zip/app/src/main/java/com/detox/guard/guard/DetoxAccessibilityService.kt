package com.detox.guard.guard

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.SystemClock
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.detox.guard.R
import com.detox.guard.engine.RestrictionStore
import com.detox.guard.engine.ScheduleEngine
import com.detox.guard.vpn.DnsVpnService

/**
 * Enforcement layer. It evaluates the schedule LIVE on every event (not only on alarms), so blocking
 * keeps working even if an alarm was delayed by battery optimisation.
 * - blocked app in front  -> HOME + overlay
 * - blocked Settings page -> BACK (HOME if it repeats) + overlay
 * Style adapted from Devilarm's TamperGuardAccessibilityService.
 */
class DetoxAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "DetoxA11y"
        private const val MAX_NODES = 400

        @Volatile var connected = false

        val SETTINGS_PACKAGES = setOf(
            "com.android.settings",
            "com.miui.securitycenter",
            "com.android.packageinstaller",
            "com.google.android.packageinstaller",
            "com.samsung.android.packageinstaller",
            "com.android.permissioncontroller",
            "com.google.android.permissioncontroller",
            "com.coloros.safecenter",
            "com.vivo.permissionmanager",
            "com.iqoo.secure",
            "com.huawei.systemmanager"
        )

        private val ALWAYS_ALLOWED = setOf(
            "com.android.systemui", "android",
            "com.android.phone", "com.android.server.telecom", "com.android.emergency",
            "com.android.dialer", "com.google.android.dialer", "com.samsung.android.incallui"
        )
    }

    private var allowed: Set<String> = ALWAYS_ALLOWED
    private var lastActionAt = 0L
    private var lastSyncAt = 0L
    private var lastSettingsHitAt = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        connected = true
        val extra = HashSet<String>()
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        packageManager.queryIntentActivities(home, 0).forEach { extra.add(it.activityInfo.packageName) }
        packageManager.queryIntentActivities(Intent(Intent.ACTION_DIAL), 0).forEach { extra.add(it.activityInfo.packageName) }
        allowed = ALWAYS_ALLOWED + extra
        Log.d(TAG, "connected, allowed=$allowed")
    }

    override fun onUnbind(intent: Intent?): Boolean {
        connected = false
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        val pkg = event.packageName?.toString() ?: return
        val now = SystemClock.elapsedRealtime()
        val snap = RestrictionStore.snapshot()

        // Fallback VPN sync in case the alarm was late (at most every 30s)
        if (now - lastSyncAt > 30_000L) {
            lastSyncAt = now
            if (snap.adult != DnsVpnService.running) ScheduleEngine.syncVpn(applicationContext, snap)
        }

        if (pkg == packageName || pkg in allowed) return
        if (!snap.apps && !snap.settings) return

        if (snap.apps) {
            val label = RestrictionStore.blockedApps[pkg]
            if (label != null) {
                if (now - lastActionAt > 700L) {
                    lastActionAt = now
                    performGlobalAction(GLOBAL_ACTION_HOME)
                    BlockOverlay.show(this, "$label abhi blocked hai.\nFocus time chal raha hai.")
                }
                return
            }
        }

        if (snap.settings && pkg in SETTINGS_PACKAGES) handleSettings(event, now)
    }

    private fun handleSettings(event: AccessibilityEvent, now: Long) {
        if (now - lastActionAt < 500L) return
        val root = rootInActiveWindow ?: return
        try {
            val titles = collectTitles(event, root)
            var hit = matchRule(titles)
            if (hit == null && RestrictionStore.prefs.state.value.strictMode && screenMentionsThisApp(root)) {
                hit = "Detox Guard"
            }
            if (hit != null) {
                lastActionAt = now
                val repeated = now - lastSettingsHitAt < 2500L
                lastSettingsHitAt = now
                performGlobalAction(if (repeated) GLOBAL_ACTION_HOME else GLOBAL_ACTION_BACK)
                BlockOverlay.show(this, "\"$hit\" settings abhi blocked hai.")
            }
        } catch (e: Exception) {
            Log.w(TAG, "settings check failed", e)
        }
    }

    private fun matchRule(titles: List<String>): String? {
        if (titles.isEmpty()) return null
        for (key in RestrictionStore.settingKeys) {
            val rule = SettingsCatalog.byKey[key] ?: continue
            if (titles.any { t -> rule.keywords.any { k -> t == k } }) return rule.title
        }
        for (kw in RestrictionStore.customKeywords) {
            val k = kw.lowercase()
            if (titles.any { it.contains(k) }) return kw
        }
        return null
    }

    /** Window title from the event text plus text inside toolbar-like nodes (not list items). */
    private fun collectTitles(event: AccessibilityEvent, root: AccessibilityNodeInfo): List<String> {
        val out = ArrayList<String>()
        event.text?.forEach { cs ->
            cs?.toString()?.trim()?.lowercase()?.takeIf { it.isNotEmpty() }?.let { out.add(it) }
        }
        var visited = 0
        fun walk(node: AccessibilityNodeInfo, inBar: Boolean) {
            if (visited++ > MAX_NODES) return
            val id = node.viewIdResourceName?.lowercase().orEmpty()
            val bar = inBar || id.contains("toolbar") || id.contains("action_bar") || id.contains("app_bar")
            if (bar) {
                node.text?.toString()?.trim()?.lowercase()?.takeIf { it.isNotEmpty() }?.let { out.add(it) }
            }
            for (i in 0 until node.childCount) {
                node.getChild(i)?.let { walk(it, bar) }
            }
        }
        walk(root, false)
        return out
    }

    /** Strict mode: any Settings screen that shows this app (App info, uninstall, a11y entry). */
    private fun screenMentionsThisApp(root: AccessibilityNodeInfo): Boolean {
        val label = getString(R.string.app_name).lowercase()
        val guardLabel = getString(R.string.guard_service_label).lowercase()
        val pkgName = packageName.lowercase()
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.addLast(root)
        var visited = 0
        while (stack.isNotEmpty() && visited < MAX_NODES) {
            val node = stack.removeLast()
            visited++
            val text = node.text?.toString()?.lowercase()
            val desc = node.contentDescription?.toString()?.lowercase()
            if (m(text, label, guardLabel, pkgName) || m(desc, label, guardLabel, pkgName)) return true
            for (i in 0 until node.childCount) node.getChild(i)?.let { stack.addLast(it) }
        }
        return false
    }

    private fun m(v: String?, label: String, guardLabel: String, pkg: String): Boolean =
        !v.isNullOrEmpty() && (v.contains(label) || v.contains(guardLabel) || v.contains(pkg))

    override fun onInterrupt() {}
}
