package com.detox.guard

import android.app.Application
import com.detox.guard.engine.RestrictionStore

class DetoxApp : Application() {
    override fun onCreate() {
        super.onCreate()
        RestrictionStore.init(this)
    }
}
