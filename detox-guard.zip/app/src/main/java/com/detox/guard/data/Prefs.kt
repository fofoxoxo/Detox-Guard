package com.detox.guard.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class PrefsState(
    val focusUntil: Long = 0L,
    val alwaysAdult: Boolean = false,
    val keywordFilter: Boolean = true,
    val strictMode: Boolean = false,
    val upstreamDns: String = ""
)

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("detox_prefs", Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(
        PrefsState(
            focusUntil = sp.getLong("focus_until", 0L),
            alwaysAdult = sp.getBoolean("always_adult", false),
            keywordFilter = sp.getBoolean("keyword_filter", true),
            strictMode = sp.getBoolean("strict_mode", false),
            upstreamDns = sp.getString("upstream_dns", "") ?: ""
        )
    )
    val state: StateFlow<PrefsState> = _state.asStateFlow()

    fun update(block: (PrefsState) -> PrefsState) {
        val n = block(_state.value)
        sp.edit()
            .putLong("focus_until", n.focusUntil)
            .putBoolean("always_adult", n.alwaysAdult)
            .putBoolean("keyword_filter", n.keywordFilter)
            .putBoolean("strict_mode", n.strictMode)
            .putString("upstream_dns", n.upstreamDns)
            .apply()
        _state.value = n
    }

    var seeded: Boolean
        get() = sp.getBoolean("seeded_v1", false)
        set(v) { sp.edit().putBoolean("seeded_v1", v).apply() }
}
