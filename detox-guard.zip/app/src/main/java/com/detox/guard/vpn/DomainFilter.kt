package com.detox.guard.vpn

import com.detox.guard.data.DomainEntry
import com.detox.guard.engine.RestrictionStore
import java.util.concurrent.atomic.AtomicLong

/** Offline domain matcher: allow-list first, then block-list (with parent domains), then keywords. */
object DomainFilter {
    @Volatile private var blocked: Set<String> = emptySet()
    @Volatile private var allowed: Set<String> = emptySet()

    val blockedCount = AtomicLong(0)
    @Volatile var lastBlocked: String = ""

    private val KEYWORDS = listOf(
        "porn", "xxx", "xvideo", "xnxx", "xhamster", "hentai", "redtube", "youporn", "sexcam", "camgirl"
    )

    fun update(entries: List<DomainEntry>) {
        val b = HashSet<String>()
        val a = HashSet<String>()
        for (e in entries) if (e.allow) a.add(e.domain) else b.add(e.domain)
        blocked = b
        allowed = a
    }

    private fun matches(set: Set<String>, name: String): Boolean {
        var d = name
        while (true) {
            if (d in set) return true
            val i = d.indexOf('.')
            if (i < 0) return false
            d = d.substring(i + 1)
        }
    }

    fun isBlocked(name: String): Boolean {
        if (matches(allowed, name)) return false
        val hit = matches(blocked, name) ||
            (RestrictionStore.prefs.state.value.keywordFilter && KEYWORDS.any { name.contains(it) })
        if (hit) {
            blockedCount.incrementAndGet()
            lastBlocked = name
        }
        return hit
    }
}
