package com.detox.guard.engine

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.detox.guard.MainActivity
import com.detox.guard.vpn.DnsVpnService

/** Alarm plumbing, adapted from Devilarm's AlarmScheduler: exact when allowed, inexact fallback otherwise. */
object DetoxScheduler {
    private const val TAG = "DetoxScheduler"
    const val ACTION_TICK = "com.detox.guard.ACTION_TICK"
    private const val REQUEST_CODE = 7001

    fun canScheduleExact(context: Context): Boolean {
        val am = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return false
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) am.canScheduleExactAlarms() else true
    }

    private fun pending(context: Context): PendingIntent {
        val intent = Intent(context, ScheduleReceiver::class.java).setAction(ACTION_TICK)
        return PendingIntent.getBroadcast(
            context, REQUEST_CODE, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun cancel(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        am.cancel(pending(context))
    }

    /** Arms one alarm for the next schedule boundary or the end of a focus session. */
    fun scheduleNext(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val now = System.currentTimeMillis()
        val candidates = ArrayList<Long>()
        ScheduleLogic.nextBoundaryMillis(RestrictionStore.schedules, now)?.let { candidates.add(it) }
        val focusUntil = RestrictionStore.prefs.state.value.focusUntil
        if (focusUntil > now) candidates.add(focusUntil)
        if (candidates.isEmpty()) {
            cancel(context)
            return
        }
        val at = candidates.min()
        val pi = pending(context)
        try {
            if (canScheduleExact(context)) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        } catch (e: SecurityException) {
            try {
                am.set(AlarmManager.RTC_WAKEUP, at, pi)
            } catch (ex: Exception) {
                Log.e(TAG, "Fallback scheduling failed", ex)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Scheduling failed", e)
        }
    }
}

object ScheduleEngine {
    private const val CHANNEL = "detox_status"

    /** Re-evaluates everything: VPN on/off for the current state and re-arms the next alarm. */
    fun apply(context: Context) {
        val c = context.applicationContext
        syncVpn(c, RestrictionStore.snapshot())
        DetoxScheduler.scheduleNext(c)
    }

    fun syncVpn(context: Context, snap: Snapshot) {
        if (snap.adult) {
            if (DnsVpnService.running) return
            if (VpnService.prepare(context) == null) {
                DnsVpnService.start(context)
            } else {
                notifyConsentNeeded(context)
            }
        } else if (DnsVpnService.running) {
            DnsVpnService.stop(context)
        }
    }

    private fun notifyConsentNeeded(context: Context) {
        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Detox status", NotificationManager.IMPORTANCE_DEFAULT))
        val pi = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("Detox Guard")
            .setContentText("Adult filter ke liye VPN permission do (app kholo > Setup)")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(7003, n)
    }
}

class ScheduleReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            DetoxScheduler.ACTION_TICK,
            Intent.ACTION_BOOT_COMPLETED,
            "android.intent.action.QUICKBOOT_POWERON",
            Intent.ACTION_MY_PACKAGE_REPLACED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            "android.app.action.SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED" -> ScheduleEngine.apply(context)
        }
    }
}
