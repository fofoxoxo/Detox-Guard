package com.detox.guard

import android.Manifest
import android.app.Activity
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import com.detox.guard.engine.ScheduleEngine
import com.detox.guard.ui.DetoxRoot
import com.detox.guard.ui.DetoxTheme
import com.detox.guard.ui.MainViewModel

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    private var permTick by mutableIntStateOf(0)

    private val vpnLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) ScheduleEngine.apply(this)
        permTick++
    }
    private val notifLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { permTick++ }
    private val fileLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importDomains(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DetoxTheme {
                DetoxRoot(
                    vm = vm,
                    permTick = permTick,
                    onRequestVpn = {
                        val i = VpnService.prepare(this)
                        if (i != null) vpnLauncher.launch(i) else ScheduleEngine.apply(this)
                    },
                    onRequestNotif = {
                        if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    },
                    onPickFile = { fileLauncher.launch(arrayOf("*/*")) }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        permTick++
        ScheduleEngine.apply(this)
    }
}
