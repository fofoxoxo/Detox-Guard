package com.detox.guard.vpn

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.detox.guard.MainActivity
import com.detox.guard.engine.RestrictionStore
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.concurrent.Executors

/**
 * Local-only VPN. Only the fake DNS server address (10.255.255.1/32) is routed into the tunnel,
 * so normal traffic is untouched. Every DNS query is checked against [DomainFilter]:
 * blocked -> NXDOMAIN answered locally, allowed -> forwarded to the real DNS through a protected socket.
 */
class DnsVpnService : VpnService() {

    companion object {
        private const val TAG = "DnsVpnService"
        const val ACTION_START = "com.detox.guard.vpn.START"
        const val DNS_ADDR = "10.255.255.1"
        const val CLIENT_ADDR = "10.255.255.2"
        private const val CHANNEL_ID = "detox_vpn"
        private const val NOTIF_ID = 7002
        private val IPV4 = Regex("""\d{1,3}(\.\d{1,3}){3}""")

        @Volatile var running = false

        fun start(ctx: Context) {
            val i = Intent(ctx, DnsVpnService::class.java).setAction(ACTION_START)
            try {
                ContextCompat.startForegroundService(ctx, i)
            } catch (e: Exception) {
                Log.w(TAG, "startForegroundService refused, trying startService", e)
                try { ctx.startService(i) } catch (e2: Exception) { Log.w(TAG, "startService failed", e2) }
            }
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, DnsVpnService::class.java))
        }
    }

    private var tun: ParcelFileDescriptor? = null
    private var worker: Thread? = null
    @Volatile private var stopping = false
    private val pool = Executors.newCachedThreadPool()

    @Volatile private var upstreamCache: List<InetAddress> = emptyList()
    @Volatile private var upstreamAt = 0L

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        if (!RestrictionStore.snapshot().adult) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!running) establish()
        return START_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Detox DNS filter", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("Detox Guard")
            .setContentText("Adult content filter ON (offline DNS)")
            .setOngoing(true)
            .setContentIntent(pi)
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(NOTIF_ID, n)
            }
        } catch (e: Exception) {
            Log.w(TAG, "startForeground failed", e)
        }
    }

    private fun establish() {
        try {
            val builder = Builder()
                .setSession("Detox DNS Filter")
                .setMtu(1500)
                .addAddress(CLIENT_ADDR, 32)
                .addDnsServer(DNS_ADDR)
                .addRoute(DNS_ADDR, 32)
                .setBlocking(true)
            val pfd = builder.establish()
            if (pfd == null) {
                stopSelf()
                return
            }
            tun = pfd
            stopping = false
            running = true
            worker = Thread({ loop(pfd) }, "detox-dns").also { it.start() }
        } catch (e: Exception) {
            Log.e(TAG, "establish failed", e)
            stopSelf()
        }
    }

    private fun loop(pfd: ParcelFileDescriptor) {
        val input = FileInputStream(pfd.fileDescriptor)
        val output = FileOutputStream(pfd.fileDescriptor)
        val buf = ByteArray(32767)
        try {
            while (!stopping) {
                val n = input.read(buf)
                if (n < 0) break
                if (n == 0) continue
                val q = DnsPacket.parse(buf, n) ?: continue
                if (DomainFilter.isBlocked(q.name)) {
                    write(output, DnsPacket.wrap(q, DnsPacket.blockedDns(q)))
                } else {
                    pool.execute { forward(q, output) }
                }
            }
        } catch (e: IOException) {
            if (!stopping) Log.w(TAG, "tunnel read ended", e)
        }
    }

    private fun write(out: FileOutputStream, bytes: ByteArray) {
        try {
            synchronized(out) { out.write(bytes) }
        } catch (e: IOException) {
            if (!stopping) Log.w(TAG, "tunnel write failed", e)
        }
    }

    private fun forward(q: DnsPacket.Query, out: FileOutputStream) {
        for (server in upstreams()) {
            try {
                DatagramSocket().use { s ->
                    protect(s)
                    s.soTimeout = 3500
                    s.connect(InetSocketAddress(server, 53))
                    s.send(DatagramPacket(q.dns, q.dns.size))
                    val rb = ByteArray(4096)
                    val rp = DatagramPacket(rb, rb.size)
                    s.receive(rp)
                    write(out, DnsPacket.wrap(q, rb.copyOf(rp.length)))
                }
                return
            } catch (e: Exception) {
                Log.d(TAG, "upstream $server failed: ${e.message}")
            }
        }
    }

    private fun upstreams(): List<InetAddress> {
        val now = SystemClock.elapsedRealtime()
        if (upstreamCache.isNotEmpty() && now - upstreamAt < 10_000) return upstreamCache
        val list = ArrayList<InetAddress>()
        val custom = RestrictionStore.prefs.state.value.upstreamDns
        custom.split(',', ' ', ';').map { it.trim() }.filter { IPV4.matches(it) }.forEach {
            try { list.add(InetAddress.getByName(it)) } catch (e: Exception) { /* ignore bad entry */ }
        }
        if (list.isEmpty()) {
            try {
                val cm = getSystemService(ConnectivityManager::class.java)
                @Suppress("DEPRECATION")
                for (net in cm.allNetworks) {
                    val caps = cm.getNetworkCapabilities(net) ?: continue
                    if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) continue
                    if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) continue
                    cm.getLinkProperties(net)?.dnsServers?.let { list.addAll(it) }
                }
            } catch (e: Exception) {
                Log.w(TAG, "could not read system DNS", e)
            }
        }
        for (fallback in listOf("1.1.1.1", "8.8.8.8")) {
            try { list.add(InetAddress.getByName(fallback)) } catch (e: Exception) { /* ignore */ }
        }
        upstreamCache = list.distinct()
        upstreamAt = now
        return upstreamCache
    }

    private fun teardown() {
        stopping = true
        running = false
        try { tun?.close() } catch (e: Exception) { Log.w(TAG, "close failed", e) }
        tun = null
        worker?.interrupt()
        worker = null
    }

    override fun onRevoke() {
        teardown()
        super.onRevoke()
    }

    override fun onDestroy() {
        teardown()
        pool.shutdownNow()
        super.onDestroy()
    }
}
