package com.detox.guard.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Scheme = darkColorScheme(
    primary = Color(0xFF8FB4FF),
    onPrimary = Color(0xFF00204D),
    secondary = Color(0xFF7DD3B0),
    background = Color(0xFF0F1318),
    surface = Color(0xFF0F1318),
    surfaceVariant = Color(0xFF1C232C),
    onSurface = Color(0xFFE6E9EE),
    onSurfaceVariant = Color(0xFFA8B0BB),
    error = Color(0xFFFF8A80)
)

@Composable
fun DetoxTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
