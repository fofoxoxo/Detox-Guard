package com.detox.guard.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "blocked_apps")
data class BlockedApp(@PrimaryKey val packageName: String, val label: String)

/** Presence of a row = that catalog settings-page rule is enabled. */
@Entity(tableName = "settings_blocks")
data class SettingsBlock(@PrimaryKey val ruleKey: String)

@Entity(tableName = "custom_keywords")
data class CustomKeyword(@PrimaryKey val keyword: String)

@Entity(tableName = "domains")
data class DomainEntry(
    @PrimaryKey val domain: String,
    val allow: Boolean = false,
    val builtIn: Boolean = false
)

/** daysMask: bit0 = Monday ... bit6 = Sunday. start > end means the window crosses midnight. */
@Entity(tableName = "schedules")
data class Schedule(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val daysMask: Int,
    val startMinute: Int,
    val endMinute: Int,
    val enabled: Boolean = true,
    val blockApps: Boolean = true,
    val blockSettings: Boolean = true,
    val blockAdult: Boolean = true
)

@Dao
interface DetoxDao {
    @Query("SELECT * FROM blocked_apps ORDER BY label COLLATE NOCASE")
    fun appsFlow(): Flow<List<BlockedApp>>

    @Query("SELECT * FROM blocked_apps")
    suspend fun apps(): List<BlockedApp>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertApp(app: BlockedApp)

    @Query("DELETE FROM blocked_apps WHERE packageName = :pkg")
    suspend fun deleteApp(pkg: String)

    @Query("SELECT * FROM settings_blocks")
    fun settingBlocksFlow(): Flow<List<SettingsBlock>>

    @Query("SELECT * FROM settings_blocks")
    suspend fun settingBlocks(): List<SettingsBlock>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSettingBlock(b: SettingsBlock)

    @Query("DELETE FROM settings_blocks WHERE ruleKey = :k")
    suspend fun deleteSettingBlock(k: String)

    @Query("SELECT * FROM custom_keywords ORDER BY keyword")
    fun keywordsFlow(): Flow<List<CustomKeyword>>

    @Query("SELECT * FROM custom_keywords")
    suspend fun keywords(): List<CustomKeyword>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertKeyword(k: CustomKeyword)

    @Query("DELETE FROM custom_keywords WHERE keyword = :k")
    suspend fun deleteKeyword(k: String)

    @Query("SELECT * FROM domains")
    suspend fun domains(): List<DomainEntry>

    @Query("SELECT * FROM domains WHERE builtIn = 0 ORDER BY domain")
    fun customDomainsFlow(): Flow<List<DomainEntry>>

    @Query("SELECT COUNT(*) FROM domains WHERE allow = 0")
    fun blockedDomainCountFlow(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDomains(list: List<DomainEntry>)

    @Query("DELETE FROM domains WHERE domain = :d")
    suspend fun deleteDomain(d: String)

    @Query("SELECT * FROM schedules ORDER BY startMinute")
    fun schedulesFlow(): Flow<List<Schedule>>

    @Query("SELECT * FROM schedules")
    suspend fun schedules(): List<Schedule>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSchedule(s: Schedule): Long

    @Query("DELETE FROM schedules WHERE id = :id")
    suspend fun deleteSchedule(id: Long)
}

@Database(
    entities = [BlockedApp::class, SettingsBlock::class, CustomKeyword::class, DomainEntry::class, Schedule::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): DetoxDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext, AppDatabase::class.java, "detox.db"
            ).build().also { instance = it }
        }
    }
}
