package com.detox.guard.ui

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.detox.guard.data.AppDatabase
import com.detox.guard.data.BlockedApp
import com.detox.guard.data.CustomKeyword
import com.detox.guard.data.DomainEntry
import com.detox.guard.data.Schedule
import com.detox.guard.data.SettingsBlock
import com.detox.guard.engine.RestrictionStore
import com.detox.guard.engine.ScheduleEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class InstalledApp(val pkg: String, val label: String)

class MainViewModel(private val app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).dao()
    private val keep = SharingStarted.WhileSubscribed(5000)

    val apps = dao.appsFlow().stateIn(viewModelScope, keep, emptyList<BlockedApp>())
    val settingKeys: StateFlow<Set<String>> = dao.settingBlocksFlow()
        .map { list -> list.map { it.ruleKey }.toSet() }
        .stateIn(viewModelScope, keep, emptySet())
    val keywords = dao.keywordsFlow().stateIn(viewModelScope, keep, emptyList<CustomKeyword>())
    val schedules = dao.schedulesFlow().stateIn(viewModelScope, keep, emptyList<Schedule>())
    val customDomains = dao.customDomainsFlow().stateIn(viewModelScope, keep, emptyList<DomainEntry>())
    val blockedDomainCount = dao.blockedDomainCountFlow().stateIn(viewModelScope, keep, 0)
    val prefs = RestrictionStore.prefs.state

    val installed = MutableStateFlow<List<InstalledApp>>(emptyList())
    val message = MutableStateFlow("")

    private fun mutate(domains: Boolean = false, block: suspend () -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            block()
            RestrictionStore.reloadCore(app)
            if (domains) RestrictionStore.reloadDomains(app)
            ScheduleEngine.apply(app)
        }
    }

    fun loadInstalled() {
        viewModelScope.launch(Dispatchers.IO) {
            val pm = app.packageManager
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            installed.value = pm.queryIntentActivities(i, 0)
                .map { InstalledApp(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
                .filter { it.pkg != app.packageName }
                .distinctBy { it.pkg }
                .sortedBy { it.label.lowercase() }
        }
    }

    fun toggleApp(a: InstalledApp, blocked: Boolean) = mutate {
        if (blocked) dao.insertApp(BlockedApp(a.pkg, a.label)) else dao.deleteApp(a.pkg)
    }

    fun removeApp(pkg: String) = mutate { dao.deleteApp(pkg) }

    fun toggleSetting(key: String, on: Boolean) = mutate {
        if (on) dao.insertSettingBlock(SettingsBlock(key)) else dao.deleteSettingBlock(key)
    }

    fun addKeyword(k: String) {
        val t = k.trim()
        if (t.isNotEmpty()) mutate { dao.insertKeyword(CustomKeyword(t)) }
    }

    fun removeKeyword(k: String) = mutate { dao.deleteKeyword(k) }

    fun saveSchedule(s: Schedule) = mutate { dao.upsertSchedule(s) }
    fun deleteSchedule(id: Long) = mutate { dao.deleteSchedule(id) }

    fun startFocus(minutes: Int) {
        RestrictionStore.prefs.update { it.copy(focusUntil = System.currentTimeMillis() + minutes * 60_000L) }
        mutate { }
    }

    fun stopFocus() {
        if (RestrictionStore.prefs.state.value.strictMode) return
        RestrictionStore.prefs.update { it.copy(focusUntil = 0L) }
        mutate { }
    }

    fun setAlwaysAdult(on: Boolean) {
        RestrictionStore.prefs.update { it.copy(alwaysAdult = on) }
        mutate { }
    }

    fun setKeywordFilter(on: Boolean) = RestrictionStore.prefs.update { it.copy(keywordFilter = on) }
    fun setStrict(on: Boolean) = RestrictionStore.prefs.update { it.copy(strictMode = on) }
    fun setUpstream(v: String) = RestrictionStore.prefs.update { it.copy(upstreamDns = v.trim()) }

    fun addDomain(raw: String, allow: Boolean) {
        val d = RestrictionStore.normalize(raw)
        if (d == null) {
            message.value = "Domain sahi nahi hai"
            return
        }
        mutate(domains = true) { dao.insertDomains(listOf(DomainEntry(d, allow, false))) }
    }

    fun removeDomain(d: String) = mutate(domains = true) { dao.deleteDomain(d) }

    fun importDomains(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val list = app.contentResolver.openInputStream(uri)!!.bufferedReader().useLines {
                    RestrictionStore.parseDomains(it)
                }
                list.chunked(5000).forEach { chunk ->
                    dao.insertDomains(chunk.map { DomainEntry(it, allow = false, builtIn = false) })
                }
                RestrictionStore.reloadDomains(app)
                message.value = "${list.size} domains import hue"
            } catch (e: Exception) {
                message.value = "Import fail: ${e.message}"
            }
        }
    }
}
