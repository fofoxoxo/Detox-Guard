package com.detox.guard.engine

import android.app.Application
import android.content.Context
import com.detox.guard.data.AppDatabase
import com.detox.guard.data.DomainEntry
import com.detox.guard.data.Prefs
import com.detox.guard.data.Schedule
import com.detox.guard.vpn.DomainFilter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking

/** In-memory mirror of the Room tables, read by the accessibility service and VPN on the hot path. */
object RestrictionStore {
    lateinit var prefs: Prefs
        private set

    @Volatile var blockedApps: Map<String, String> = emptyMap()   // package -> label
    @Volatile var settingKeys: Set<String> = emptySet()
    @Volatile var customKeywords: List<String> = emptyList()
    @Volatile var schedules: List<Schedule> = emptyList()

    fun init(app: Application) {
        prefs = Prefs(app)
        runBlocking(Dispatchers.IO) { reloadCore(app) }
        Thread {
            runBlocking {
                seedIfNeeded(app)
                reloadDomains(app)
            }
        }.start()
    }

    fun snapshot(now: Long = System.currentTimeMillis()): Snapshot =
        ScheduleLogic.compute(schedules, prefs.state.value, now)

    suspend fun reloadCore(ctx: Context) {
        val dao = AppDatabase.get(ctx).dao()
        blockedApps = dao.apps().associate { it.packageName to it.label }
        settingKeys = dao.settingBlocks().map { it.ruleKey }.toSet()
        customKeywords = dao.keywords().map { it.keyword }
        schedules = dao.schedules()
    }

    suspend fun reloadDomains(ctx: Context) {
        DomainFilter.update(AppDatabase.get(ctx).dao().domains())
    }

    private suspend fun seedIfNeeded(ctx: Context) {
        if (prefs.seeded) return
        try {
            val list = ArrayList<DomainEntry>()
            ctx.assets.open("adult_domains.txt").bufferedReader().useLines { lines ->
                parseDomains(lines).forEach { list.add(DomainEntry(it, allow = false, builtIn = true)) }
            }
            AppDatabase.get(ctx).dao().insertDomains(list)
            prefs.seeded = true
        } catch (e: Exception) {
            android.util.Log.w("RestrictionStore", "Seeding failed", e)
        }
    }

    /** Accepts plain domains and hosts-file lines ("0.0.0.0 example.com"). */
    fun parseDomains(lines: Sequence<String>): List<String> {
        val out = LinkedHashSet<String>()
        for (raw in lines) {
            val line = raw.substringBefore('#').trim()
            if (line.isEmpty()) continue
            val parts = line.split(Regex("\\s+"))
            val token = if (parts.size >= 2 && (parts[0] == "0.0.0.0" || parts[0] == "127.0.0.1")) parts[1] else parts[0]
            val d = normalize(token) ?: continue
            if (d == "localhost") continue
            out.add(d)
        }
        return out.toList()
    }

    fun normalize(input: String): String? {
        val d = input.trim().lowercase().removePrefix("http://").removePrefix("https://")
            .substringBefore('/').trimEnd('.').removePrefix("www.")
        if (d.isEmpty() || !d.contains('.')) return null
        if (!Regex("^[a-z0-9._-]+$").matches(d)) return null
        return d
    }
}
