package com.detox.guard.vpn

/** Minimal IPv4/UDP/DNS parsing and reply building for the local DNS sinkhole. */
object DnsPacket {
    class Query(
        val srcIp: ByteArray,
        val dstIp: ByteArray,
        val srcPort: Int,
        val dstPort: Int,
        val dns: ByteArray,
        val name: String,
        val type: Int,
        val questionEnd: Int
    )

    private fun u16(b: ByteArray, o: Int): Int = ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)

    fun parse(p: ByteArray, len: Int): Query? {
        if (len < 20 + 8 + 12) return null
        if (((p[0].toInt() and 0xFF) shr 4) != 4) return null
        val ihl = (p[0].toInt() and 0x0F) * 4
        if (ihl < 20 || len < ihl + 8 + 12) return null
        if ((p[9].toInt() and 0xFF) != 17) return null
        val srcPort = u16(p, ihl)
        val dstPort = u16(p, ihl + 2)
        if (dstPort != 53) return null
        val udpLen = u16(p, ihl + 4)
        val dnsStart = ihl + 8
        val dnsLen = minOf(udpLen - 8, len - dnsStart)
        if (dnsLen < 12) return null
        val dns = p.copyOfRange(dnsStart, dnsStart + dnsLen)
        if ((dns[2].toInt() and 0x80) != 0) return null      // it is a response
        if (u16(dns, 4) < 1) return null                     // no question

        var i = 12
        val sb = StringBuilder()
        while (true) {
            if (i >= dns.size) return null
            val l = dns[i].toInt() and 0xFF
            if (l == 0) { i++; break }
            if ((l and 0xC0) != 0 || i + 1 + l > dns.size) return null
            sb.append(String(dns, i + 1, l, Charsets.ISO_8859_1)).append('.')
            i += 1 + l
        }
        if (i + 4 > dns.size) return null
        val name = sb.toString().trimEnd('.').lowercase()
        return Query(
            p.copyOfRange(12, 16), p.copyOfRange(16, 20),
            srcPort, dstPort, dns, name, u16(dns, i), i + 4
        )
    }

    /** NXDOMAIN reply for a blocked name (header + original question). */
    fun blockedDns(q: Query): ByteArray {
        val out = ByteArray(q.questionEnd)
        System.arraycopy(q.dns, 0, out, 0, q.questionEnd)
        val rd = q.dns[2].toInt() and 0x01
        out[2] = (0x80 or rd).toByte()      // QR=1, RD copied
        out[3] = (0x80 or 0x03).toByte()    // RA=1, RCODE=3 (NXDOMAIN)
        out[4] = 0; out[5] = 1              // QDCOUNT = 1
        for (k in 6..11) out[k] = 0         // AN/NS/AR = 0
        return out
    }

    /** Wraps a DNS payload into an IPv4 + UDP packet going back to the asker. */
    fun wrap(q: Query, dns: ByteArray): ByteArray {
        val total = 20 + 8 + dns.size
        val pkt = ByteArray(total)
        pkt[0] = 0x45
        pkt[2] = (total shr 8).toByte(); pkt[3] = total.toByte()
        pkt[6] = 0x40                       // DF
        pkt[8] = 64                         // TTL
        pkt[9] = 17                         // UDP
        System.arraycopy(q.dstIp, 0, pkt, 12, 4)   // src = the fake DNS server
        System.arraycopy(q.srcIp, 0, pkt, 16, 4)   // dst = the asker
        var sum = 0
        var k = 0
        while (k < 20) { sum += u16(pkt, k); k += 2 }
        while ((sum shr 16) != 0) sum = (sum and 0xFFFF) + (sum shr 16)
        val csum = sum.inv() and 0xFFFF
        pkt[10] = (csum shr 8).toByte(); pkt[11] = csum.toByte()

        pkt[20] = (q.dstPort shr 8).toByte(); pkt[21] = q.dstPort.toByte()
        pkt[22] = (q.srcPort shr 8).toByte(); pkt[23] = q.srcPort.toByte()
        val udpLen = 8 + dns.size
        pkt[24] = (udpLen shr 8).toByte(); pkt[25] = udpLen.toByte()
        // UDP checksum 0 = not used (valid for IPv4)
        System.arraycopy(dns, 0, pkt, 28, dns.size)
        return pkt
    }
}
