package com.detox.guard.guard

/** Settings pages the user can choose to block. Keywords are matched against the page TITLE (exact). */
data class SettingsRule(val key: String, val title: String, val keywords: List<String>)

object SettingsCatalog {
    val rules = listOf(
        SettingsRule("accessibility", "Accessibility", listOf("accessibility", "सुलभता", "एक्सेसिबिलिटी")),
        SettingsRule("vpn", "VPN", listOf("vpn")),
        SettingsRule("private_dns", "Private DNS", listOf("private dns", "निजी डीएनएस")),
        SettingsRule("developer", "Developer options", listOf("developer options", "डेवलपर विकल्प")),
        SettingsRule("datetime", "Date & time", listOf("date & time", "date and time", "तारीख और समय")),
        SettingsRule("device_admin", "Device admin apps", listOf("device admin apps", "device admin app", "device administrators")),
        SettingsRule("unknown_apps", "Install unknown apps", listOf("install unknown apps", "install unknown app")),
        SettingsRule("reset", "Reset options", listOf("reset options", "reset", "factory data reset")),
        SettingsRule("apps", "Apps / App info list", listOf("apps", "all apps", "app info", "ऐप्लिकेशन", "ऐप्स")),
        SettingsRule("wellbeing", "Digital Wellbeing", listOf("digital wellbeing & parental controls", "digital wellbeing")),
        SettingsRule("wifi", "Wi-Fi", listOf("wi-fi", "wi\u2011fi", "wifi"))
    )
    val byKey: Map<String, SettingsRule> = rules.associateBy { it.key }
}
