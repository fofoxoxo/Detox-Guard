@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.detox.guard.ui

import android.content.Context
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.detox.guard.data.Schedule
import com.detox.guard.engine.RestrictionStore
import com.detox.guard.engine.ScheduleLogic
import com.detox.guard.guard.Permissions
import com.detox.guard.guard.SettingsCatalog
import com.detox.guard.vpn.DomainFilter
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Tab(val label: String, val emoji: String) {
    HOME("Home", "\uD83C\uDFE0"),
    APPS("Block", "\uD83D\uDCF5"),
    SCHEDULE("Schedule", "\u23F0"),
    ADULT("Adult", "\uD83D\uDEE1"),
    SETUP("Setup", "\u2699")
}

private val DAYS = listOf("Mo", "Tu", "We", "Th", "Fr", "Sa", "Su")
private fun fmtMin(m: Int) = "%02d:%02d".format(m / 60, m % 60)

@Composable
fun DetoxRoot(
    vm: MainViewModel,
    permTick: Int,
    onRequestVpn: () -> Unit,
    onRequestNotif: () -> Unit,
    onPickFile: () -> Unit
) {
    var tab by remember { mutableStateOf(Tab.HOME) }
    Scaffold(
        bottomBar = {
            NavigationBar {
                Tab.values().forEach { t ->
                    NavigationBarItem(
                        selected = tab == t,
                        onClick = { tab = t },
                        icon = { Text(t.emoji) },
                        label = { Text(t.label) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                Tab.HOME -> HomeScreen(vm)
                Tab.APPS -> BlockScreen(vm)
                Tab.SCHEDULE -> ScheduleScreen(vm)
                Tab.ADULT -> AdultScreen(vm, onRequestVpn, onPickFile)
                Tab.SETUP -> SetupScreen(vm, permTick, onRequestVpn, onRequestNotif)
            }
        }
    }
}

@Composable
private fun Title(t: String) =
    Text(t, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))

@Composable
private fun ToggleRow(title: String, sub: String? = null, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title)
            if (sub != null) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

// ----------------------------------------------------------------------------- HOME

@Composable
fun HomeScreen(vm: MainViewModel) {
    val prefs by vm.prefs.collectAsState()
    val schedules by vm.schedules.collectAsState()
    val now by produceState(System.currentTimeMillis()) {
        while (true) { value = System.currentTimeMillis(); delay(1000) }
    }
    val snap = RestrictionStore.snapshot(now)
    val next = ScheduleLogic.nextBoundaryMillis(schedules, now)

    LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(if (snap.any) "\uD83D\uDD12 Restrictions ACTIVE" else "\uD83D\uDD13 Abhi koi restriction nahi", style = MaterialTheme.typography.titleLarge)
                    Text("Apps: ${if (snap.apps) "blocked" else "free"}  |  Settings: ${if (snap.settings) "blocked" else "free"}  |  Adult: ${if (snap.adult) "filtered" else "off"}")
                    if (snap.activeNames.isNotEmpty()) Text("Schedule: " + snap.activeNames.joinToString())
                    if (next != null) {
                        Text("Next change: " + SimpleDateFormat("EEE HH:mm", Locale.getDefault()).format(Date(next)),
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Focus abhi shuru karo", style = MaterialTheme.typography.titleMedium)
                    if (snap.focusActive) {
                        val rem = (prefs.focusUntil - now) / 1000
                        Text("Bacha hua: %02d:%02d".format(rem / 60, rem % 60), style = MaterialTheme.typography.headlineSmall)
                        if (prefs.strictMode) Text("Strict mode ON: timer khatam hone tak band nahi hoga.")
                        else OutlinedButton(onClick = { vm.stopFocus() }) { Text("Focus band karo") }
                    } else {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(15, 30, 60, 120).forEach { m ->
                                OutlinedButton(onClick = { vm.startFocus(m) }, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp)) {
                                    Text(if (m >= 60) "${m / 60}h" else "${m}m")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------------------------------- BLOCK (apps + settings)

@Composable
fun BlockScreen(vm: MainViewModel) {
    val apps by vm.apps.collectAsState()
    val keys by vm.settingKeys.collectAsState()
    val kws by vm.keywords.collectAsState()
    var picker by remember { mutableStateOf(false) }
    var kwText by remember { mutableStateOf("") }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        item {
            Title("Blocked apps (${apps.size})")
            Button(onClick = { vm.loadInstalled(); picker = true }) { Text("+ Apps chuno") }
        }
        items(apps, key = { it.packageName }) { a ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(a.label, Modifier.weight(1f))
                TextButton(onClick = { vm.removeApp(a.packageName) }) { Text("Hatao") }
            }
        }
        item {
            Title("Settings pages")
            Text("Page ka title match hota hai. Sirf restriction ke time par block hota hai.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        items(SettingsCatalog.rules, key = { it.key }) { r ->
            ToggleRow(r.title, checked = r.key in keys, onChange = { vm.toggleSetting(r.key, it) })
        }
        item {
            Title("Custom keywords")
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(kwText, { kwText = it }, Modifier.weight(1f), singleLine = true, label = { Text("Page title ka hissa") })
                TextButton(onClick = { vm.addKeyword(kwText); kwText = "" }) { Text("Add") }
            }
        }
        items(kws, key = { it.keyword }) { k ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(k.keyword, Modifier.weight(1f))
                TextButton(onClick = { vm.removeKeyword(k.keyword) }) { Text("Hatao") }
            }
        }
    }
    if (picker) AppPicker(vm, apps.map { it.packageName }.toSet()) { picker = false }
}

@Composable
private fun AppPicker(vm: MainViewModel, blocked: Set<String>, onClose: () -> Unit) {
    val all by vm.installed.collectAsState()
    var q by remember { mutableStateOf("") }
    val list = all.filter { it.label.contains(q, ignoreCase = true) }
    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClick = onClose) { Text("Done") } },
        title = { Text("Apps chuno") },
        text = {
            Column {
                OutlinedTextField(q, { q = it }, singleLine = true, label = { Text("Search") }, modifier = Modifier.fillMaxWidth())
                LazyColumn(Modifier.heightIn(max = 380.dp)) {
                    items(list, key = { it.pkg }) { a ->
                        Row(Modifier.fillMaxWidth().clickable { vm.toggleApp(a, a.pkg !in blocked) }, verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = a.pkg in blocked, onCheckedChange = { vm.toggleApp(a, it) })
                            Text(a.label)
                        }
                    }
                }
            }
        }
    )
}

// ----------------------------------------------------------------------------- SCHEDULE

@Composable
fun ScheduleScreen(vm: MainViewModel) {
    val list by vm.schedules.collectAsState()
    var editing by remember { mutableStateOf<Schedule?>(null) }
    var creating by remember { mutableStateOf(false) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Button(onClick = { creating = true }) { Text("+ Naya schedule") } }
        items(list, key = { it.id }) { s ->
            Card(Modifier.fillMaxWidth().clickable { editing = s }) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(s.name, style = MaterialTheme.typography.titleMedium)
                            Text("${fmtMin(s.startMinute)} - ${fmtMin(s.endMinute)}")
                        }
                        Switch(checked = s.enabled, onCheckedChange = { vm.saveSchedule(s.copy(enabled = it)) })
                    }
                    Text(DAYS.filterIndexed { i, _ -> ((s.daysMask shr i) and 1) == 1 }.joinToString(" "), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(listOfNotNull(
                        if (s.blockApps) "Apps" else null,
                        if (s.blockSettings) "Settings" else null,
                        if (s.blockAdult) "Adult" else null
                    ).joinToString(" + "), color = MaterialTheme.colorScheme.secondary)
                    TextButton(onClick = { vm.deleteSchedule(s.id) }) { Text("Delete") }
                }
            }
        }
    }
    if (creating || editing != null) {
        ScheduleDialog(
            initial = editing,
            onDismiss = { creating = false; editing = null },
            onSave = { vm.saveSchedule(it); creating = false; editing = null }
        )
    }
}

@Composable
private fun ScheduleDialog(initial: Schedule?, onDismiss: () -> Unit, onSave: (Schedule) -> Unit) {
    var name by remember { mutableStateOf(initial?.name ?: "Focus") }
    var days by remember { mutableIntStateOf(initial?.daysMask ?: 0b0011111) }
    var start by remember { mutableIntStateOf(initial?.startMinute ?: 9 * 60) }
    var end by remember { mutableIntStateOf(initial?.endMinute ?: 17 * 60) }
    var apps by remember { mutableStateOf(initial?.blockApps ?: true) }
    var settings by remember { mutableStateOf(initial?.blockSettings ?: true) }
    var adult by remember { mutableStateOf(initial?.blockAdult ?: true) }
    var pick by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Naya schedule" else "Schedule edit") },
        confirmButton = {
            TextButton(onClick = {
                onSave(Schedule(
                    id = initial?.id ?: 0, name = name.ifBlank { "Focus" }, daysMask = days,
                    startMinute = start, endMinute = end, enabled = initial?.enabled ?: true,
                    blockApps = apps, blockSettings = settings, blockAdult = adult
                ))
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, singleLine = true, label = { Text("Naam") })
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    DAYS.forEachIndexed { i, d ->
                        val on = ((days shr i) and 1) == 1
                        Surface(
                            shape = CircleShape,
                            color = if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.size(34.dp).clickable { days = days xor (1 shl i) }
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(d, style = MaterialTheme.typography.labelSmall,
                                    color = if (on) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface)
                            }
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { pick = "start" }) { Text("Start ${fmtMin(start)}") }
                    OutlinedButton(onClick = { pick = "end" }) { Text("End ${fmtMin(end)}") }
                }
                if (start > end) Text("Raat ke paar chalega (agle din tak)", style = MaterialTheme.typography.bodySmall)
                ToggleRow("Apps block", checked = apps, onChange = { apps = it })
                ToggleRow("Settings pages block", checked = settings, onChange = { settings = it })
                ToggleRow("Adult filter (VPN)", checked = adult, onChange = { adult = it })
            }
        }
    )

    if (pick.isNotEmpty()) {
        val cur = if (pick == "start") start else end
        val st = rememberTimePickerState(initialHour = cur / 60, initialMinute = cur % 60, is24Hour = true)
        AlertDialog(
            onDismissRequest = { pick = "" },
            confirmButton = {
                TextButton(onClick = {
                    val m = st.hour * 60 + st.minute
                    if (pick == "start") start = m else end = m
                    pick = ""
                }) { Text("OK") }
            },
            text = { TimePicker(state = st) }
        )
    }
}

// ----------------------------------------------------------------------------- ADULT

@Composable
fun AdultScreen(vm: MainViewModel, onRequestVpn: () -> Unit, onPickFile: () -> Unit) {
    val ctx = LocalContext.current
    val prefs by vm.prefs.collectAsState()
    val count by vm.blockedDomainCount.collectAsState()
    val custom by vm.customDomains.collectAsState()
    val msg by vm.message.collectAsState()
    val blockedNow by produceState(0L) { while (true) { value = DomainFilter.blockedCount.get(); delay(1500) } }
    var domain by remember { mutableStateOf("") }
    var dns by remember(prefs.upstreamDns) { mutableStateOf(prefs.upstreamDns) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        item {
            ToggleRow("Hamesha adult filter ON", "Schedule ke bina bhi 24x7 (local VPN)", prefs.alwaysAdult) { on ->
                if (on && !Permissions.vpnGranted(ctx)) onRequestVpn()
                vm.setAlwaysAdult(on)
            }
            ToggleRow("Keyword filter", "porn/xxx jaise naam wale domains bhi block", prefs.keywordFilter) { vm.setKeywordFilter(it) }
            Text("Block list: $count domains  |  Block hue queries: $blockedNow" +
                (DomainFilter.lastBlocked.takeIf { it.isNotEmpty() }?.let { "\nLast: $it" } ?: ""),
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("Note: Chrome/Firefox ka 'Secure DNS' (DoH) ya Private DNS filter ko bypass kar sakta hai. Unhe OFF rakho; Private DNS page Block tab se lock ho sakta hai.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
        }
        item {
            Title("Upstream DNS (optional)")
            OutlinedTextField(dns, { dns = it }, singleLine = true, label = { Text("khali = phone ka DNS, ya 1.1.1.1") }, modifier = Modifier.fillMaxWidth())
            TextButton(onClick = { vm.setUpstream(dns) }) { Text("Save DNS") }
        }
        item {
            Title("Domain add karo")
            OutlinedTextField(domain, { domain = it }, singleLine = true, label = { Text("example.com") }, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { vm.addDomain(domain, false); domain = "" }) { Text("Block") }
                OutlinedButton(onClick = { vm.addDomain(domain, true); domain = "" }) { Text("Always allow") }
            }
            OutlinedButton(onClick = onPickFile) { Text("File import (hosts / domain list)") }
            if (msg.isNotEmpty()) Text(msg, style = MaterialTheme.typography.bodySmall)
        }
        items(custom, key = { it.domain }) { d ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text((if (d.allow) "\u2705 " else "\u26D4 ") + d.domain, Modifier.weight(1f))
                TextButton(onClick = { vm.removeDomain(d.domain) }) { Text("Hatao") }
            }
        }
    }
}

// ----------------------------------------------------------------------------- SETUP

@Composable
fun SetupScreen(vm: MainViewModel, tick: Int, onRequestVpn: () -> Unit, onRequestNotif: () -> Unit) {
    val ctx: Context = LocalContext.current
    val prefs by vm.prefs.collectAsState()
    val a11y = remember(tick) { Permissions.isAccessibilityEnabled(ctx) }
    val vpn = remember(tick) { Permissions.vpnGranted(ctx) }
    val exact = remember(tick) { Permissions.canExactAlarm(ctx) }
    val notif = remember(tick) { Permissions.hasNotifications(ctx) }
    val battery = remember(tick) { Permissions.ignoringBattery(ctx) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            PermRow("Accessibility (apps/settings block)", a11y, "Open") { Permissions.openAccessibility(ctx) }
            Text("Android 13+ par sideload app ke liye pehle: App info > \u22EE > Allow restricted settings.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            TextButton(onClick = { Permissions.openAppDetails(ctx) }) { Text("App info kholo") }
        }
        item { PermRow("VPN permission (adult filter)", vpn, "Grant") { onRequestVpn() } }
        item { PermRow("Exact alarms (time par sahi trigger)", exact, "Allow") { Permissions.openExactAlarm(ctx) } }
        item { PermRow("Notifications", notif, "Allow") { onRequestNotif() } }
        item { PermRow("Battery: unrestricted", battery, "Allow") { Permissions.requestBattery(ctx) } }
        item {
            Text(Permissions.oemGuideText(), style = MaterialTheme.typography.bodySmall)
            TextButton(onClick = { Permissions.openAutostart(ctx) }) { Text("Autostart settings") }
        }
        item {
            ToggleRow("Strict mode", "Restriction ke dauran is app ke App info/uninstall/accessibility screens bhi block, aur Focus timer beech mein band nahi hoga.",
                prefs.strictMode) { vm.setStrict(it) }
        }
    }
}

@Composable
private fun PermRow(title: String, ok: Boolean, action: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text((if (ok) "\u2705 " else "\u26A0\uFE0F ") + title, Modifier.weight(1f))
        if (!ok) OutlinedButton(onClick = onClick) { Text(action) }
    }
    Spacer(Modifier.size(2.dp))
}
