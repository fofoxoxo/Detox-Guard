package com.detox.guard.guard

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.util.Log
import androidx.core.content.ContextCompat
import com.detox.guard.engine.DetoxScheduler

/** Status checks and settings shortcuts (adapted from Devilarm's GuardPermissions). */
object Permissions {
    private const val TAG = "Permissions"

    fun hasNotifications(c: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun canExactAlarm(c: Context): Boolean = DetoxScheduler.canScheduleExact(c)

    fun vpnGranted(c: Context): Boolean = VpnService.prepare(c) == null

    fun ignoringBattery(c: Context): Boolean {
        val pm = c.getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return false
        return pm.isIgnoringBatteryOptimizations(c.packageName)
    }

    fun isAccessibilityEnabled(c: Context): Boolean = try {
        val enabled = Settings.Secure.getInt(c.contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED, 0) == 1
        if (!enabled) false else {
            val list = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
            val mine = ComponentName(c, DetoxAccessibilityService::class.java)
            list.split(':').any { ComponentName.unflattenFromString(it.trim()) == mine }
        }
    } catch (e: Exception) {
        false
    }

    private fun launch(c: Context, i: Intent): Boolean = try {
        if (c !is Activity) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        c.startActivity(i)
        true
    } catch (e: Exception) {
        Log.w(TAG, "cannot open ${i.action}", e)
        false
    }

    private fun pkgUri(c: Context) = Uri.parse("package:${c.packageName}")

    fun openAppDetails(c: Context) = launch(c, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkgUri(c)))
    fun openAccessibility(c: Context) = launch(c, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))

    fun openExactAlarm(c: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 31) launch(c, Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, pkgUri(c))) else false

    fun requestBattery(c: Context): Boolean {
        if (launch(c, Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkgUri(c)))) return true
        return launch(c, Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
    }

    private val autostartTargets = listOf(
        "com.miui.securitycenter" to "com.miui.permcenter.autostart.AutoStartManagementActivity",
        "com.coloros.safecenter" to "com.coloros.safecenter.permission.startup.StartupAppListActivity",
        "com.oppo.safe" to "com.oppo.safe.permission.startup.StartupAppListActivity",
        "com.vivo.permissionmanager" to "com.vivo.permissionmanager.activity.BgStartUpManagerActivity",
        "com.iqoo.secure" to "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity",
        "com.huawei.systemmanager" to "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"
    )

    fun openAutostart(c: Context): Boolean {
        for ((pkg, cls) in autostartTargets) {
            if (launch(c, Intent().apply { component = ComponentName(pkg, cls) })) return true
        }
        return openAppDetails(c)
    }

    fun oemGuideText(): String {
        val m = Build.MANUFACTURER.lowercase()
        return when {
            m.contains("xiaomi") || m.contains("redmi") || m.contains("poco") ->
                "Xiaomi/Redmi/POCO: Security > Permissions > Autostart mein Detox Guard ON karo, phir Battery saver > No restrictions."
            m.contains("oppo") || m.contains("realme") || m.contains("oneplus") ->
                "Oppo/Realme/OnePlus: Settings > Apps > Detox Guard > Battery usage > Allow background activity + Auto launch ON."
            m.contains("vivo") || m.contains("iqoo") ->
                "Vivo/iQOO: i Manager > App manager > Autostart ON; Battery > Background power consumption > Allow."
            m.contains("huawei") || m.contains("honor") ->
                "Huawei/Honor: Settings > Battery > App launch > Detox Guard > Manage manually, teeno toggle ON."
            m.contains("samsung") ->
                "Samsung: Settings > Battery > Background usage limits > Never sleeping apps mein Detox Guard daalo."
            else -> "App info > Battery > Unrestricted chuno; Autostart option ho to ON karo."
        }
    }
}
