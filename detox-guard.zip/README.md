# Detox Guard

Offline Digital Detox & Content Blocking app (Kotlin, Jetpack Compose, Room, Gradle KTS).

- **Accessibility blocking**: chune hue apps + Settings pages (VPN, Accessibility, Developer options...) restriction time par block.
- **Local VPN DNS filter**: sirf DNS queries tunnel mein aati hain; adult domains NXDOMAIN, baaki real DNS ko forward. Koi cloud/API nahi.
- **Scheduling engine**: Room mein schedules, AlarmManager exact alarm har start/end par, boot/time-change par re-arm. Accessibility service time ko live bhi check karta hai.
- Setup tab se permissions do: Accessibility, VPN, Exact alarm, Notifications, Battery.
